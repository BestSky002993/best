// Question #1: Shipping Cost Calculator

function calculateShippingCost(cost) {
  if(cost >= 6000){
    return "Shipping is free.";
  }else if(cost >= 3000){
    return "Shpping cost is 250 Baht.";
  }else{
    return "Shipping cost is 500 Baht";
  }
}
// ตัวอย่างการใช้งาน
const orders = [
  {
    orderId: 1,
    total: 6000,
  },
  {
    orderId: 2,
    total: 3000,
  },
  {
    orderId: 3,
    total: 150,
  }
];

for(let i = 0; i < orders.length; i++){
  const order = orders[i];
  const messge = calculateShippingCost(order.total);
  console.log(`Order Id ${order.orderId} : ${messge}`)
}
// Order Id 1: "Shipping is free."
// Order Id 2: "Shipping cost is 250 Baht."
// Order Id 3: "Shipping cost is 500 Baht."
