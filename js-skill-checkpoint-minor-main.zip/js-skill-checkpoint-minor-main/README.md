# JavaScript Skill Checkpoint

นาย อภิชัย สีหะบุตร
aphichaisihabut@gmail.com

แบบทดสอบ JavaScript ซึ่งมีทั้งหมด 2 ข้อ
